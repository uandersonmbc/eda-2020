#ifndef ITEM_H
#define ITEM_H
#include <string>

typedef std::string Tkey;
typedef std::string Tvalue;

#endif